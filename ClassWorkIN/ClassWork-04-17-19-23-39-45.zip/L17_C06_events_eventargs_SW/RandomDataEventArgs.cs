﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L17_C06_events_eventargs_SW
{
	public class RandomDataEventArgs
	{
		public int BytesDone { get; set; }
		public int TotalBytes { get; set; }
	}
}
