﻿namespace L13_C04_interface.Interface
{
	public interface IMusicPlayer
	{
		string MusicSource { get; set; }

		void PlayMusic();
	}
}
