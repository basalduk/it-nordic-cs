﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L13_C04_interface.Interface
{
	public interface IRestartable
	{
		void Restart();
	}
}
