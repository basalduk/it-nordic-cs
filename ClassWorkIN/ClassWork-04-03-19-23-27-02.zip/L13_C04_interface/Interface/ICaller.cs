﻿namespace L13_C04_interface.Interface
{
	public interface ICaller
	{
		void Call(string phoneNumber);
	}
}
